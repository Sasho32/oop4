package org.elsys.part1;

public enum Color {

	WHITE,
	RED,
	GREEN,
	BLUE,
	BLACK,
	BROWN,
	YELLOW,
	PINK,
	PURPLE
}
